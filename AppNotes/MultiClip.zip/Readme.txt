A generic way to collect multiple clipboard text areas into one temporary.txt file. Save the output file as any name you like. You could change the output to a given folder with a name of your choice.

You may not need beep.bat (see NOTE below) it is included in-case your editor can't handle control codes.

Version One
Is as per forum topic and works with any text application, by asking you to apply Copy Command (Control+C) manually see https://forum.sumatrapdfreader.org/t/how-to-copy-multiple-text-objects-and-preserve-last-zoom-scroll-state/3327

Version Two is SumatraPDF specific
It does NOT need you to use Control+C, simply select some text or using CTRL + Left Mouse, drag a selection area. The selection must include selectable text any images or image based text will be ignored.
The selection will be automatically copied for you.


NOTE for both versions, they are slow and contain timed pauses, since they both use powershell. A full .vbs or .ahk version would be generally quicker. You may find you need to adjust timings if the clipboard actions are either too fast or too slow.

Both versions contain two ^G codes (Control Gong) which create a double beep.
Some editors may inadvertently destroy that code, if so simply include the unedited beep.bat in the same folder and change the lines in the main file from either 

@echo 
:lets pause for a second to seperate the ready beeps
timeout /t 1 > nul
@echo 
	OR
@echo 
:lets pause for 900 millisecond to seperate the ready beeps
ping 192.0.2.0 -n 1 -w 900 > nul
@echo 

	TO

call "%~dp0beep.bat"
:lets pause for 900 millisecond to seperate the ready beeps
ping 192.0.2.0 -n 1 -w 900 > nul
call "%~dp0beep.bat"
