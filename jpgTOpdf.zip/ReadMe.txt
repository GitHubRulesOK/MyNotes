
jpgTOpdf.bat
------------

This is a PoC (Proof Of Concept) to show how Native Windows can write JPEG to PDF.
 
Simply drop the included GridQRcode.jpg which is a sample of a "Pixel Perfect" JPG
onto jpgTopdf.bat

HOTE the "header.txt" has been designed to keep the 2:1 ratio of images like this.

To modify that header for full page I have added fullA4L.txt. You will need to ren
header.txt as "2to1.txt" then copy over fullA4L.txt as "header.txt" for Landscape.

The ratio is fixed by the header for X & Y without any offsets so you will need to
do matrix maths for orientation, but it should be simple to modify the header just
beware which way is Y, and use variables of ###.## OR ####.# for point sizes.

The Output.pdf will be built in the %temp% directory and also saved in the working
folder use move or change the cmd file for other locations.

HWR&Wstream.js
--------------
An alternative CScript example is included so show how it can be easily done with
double click a JScript file, where the image data is inline, but could with extra
JS or cmd coding be a variable file with variable pages.