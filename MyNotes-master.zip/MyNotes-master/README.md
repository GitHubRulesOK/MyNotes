# MyNotes
ARCHIVE (App Related Cloud Help / Info / Various Experiences)

This repository is a collection of notes on other parties software,  as such it is composed of personal observations or derivative code and as such does not transfer nor confer any change to the rights of the other parties source or derivitive works.

Where MyNotes are based on others works then the license of those works apply.
e.g. If MyNotes relate to an APGL3 application then by default where appropriate the APGL3 may be applied to my work, however where not subject to, nor in contradiction to the above, MyNotes default to the attached BSD 3-Clause Clear License.
