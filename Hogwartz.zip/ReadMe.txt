 HogWartZ  (Alien graphics drawn by Bethan age 5, this version uses Cream Eggs)
 the latest EggHeadZ game for your PC ("Spirit in the Sky" by Norman Greenbaum)

Requirements
 Can be run from a floppy, no need to install to PC at school or work!, runs
 mainly in memory, but needs to write the score back to disk. Modern hardware
 may struggle to run 640 x 480 full screen so run in a seesion where you can
 switch off easily. Needs suitable Multi-graphix hardware. (I.e. DirectX 7 or above).

Aim:
 Zap the "Sly-there-in" Teachers, Wizards & Pupils to get Housepoints
 Remember you only have three spare wands and if they reach you, they will
 snap yours in two, they aim to hit your wand with their spells too!
 BEWARE DON'T hit a WFO (Weasely Flying Object), you loose 1000 points!

Instructions:
-------------
Click on Hogwartz.exe or adapt the shortcut.

 Use arrows to move Right / Left
 Press Space Bar to cast your spell
 Esc to quit

For more interest:
 Compete with a friend and best out of five takes both creme eggs.

